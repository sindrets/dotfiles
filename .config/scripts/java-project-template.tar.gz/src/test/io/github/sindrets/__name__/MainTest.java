package io.github.sindrets.__name__;

import no.stide.fling.TestGroup;
import no.stide.fling.TestInitiator;

public class MainTest {
    @TestGroup(description = "A simple test suite.")
    public void simpleTest(TestInitiator suite) {
        suite.it("should be simple with one test").expect(1).toBe(1);
    }
}
