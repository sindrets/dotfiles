package io.github.sindrets.__name__;

public class Main {
    public static void main(String args[]) {
        Logger.success("Hello world!");
    }
}
