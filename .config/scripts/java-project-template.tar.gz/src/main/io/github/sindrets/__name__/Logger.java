package io.github.sindrets.__name__;

import java.io.PrintStream;

import no.stide.jchalk.Chalk;

public class Logger {

    private static final Chalk chalk = new Chalk();
    private static final Logger logger = new Logger();

    private PrintStream stdout;
    private PrintStream stderr;
    private boolean debugMode = false;
    private int indentLevel = 0;
    private int indentSize = 4;

    public Logger(PrintStream stdout, PrintStream stderr) {
        this.stdout = stdout;
        this.stderr = stderr;
    }

    public Logger() {
        this.stdout = System.out;
        this.stderr = System.err;
    }

    private String indentObject(Object o, int n) {
        String[] lines = o.toString().split("\\n|\\r|(\\r\\n)", -1);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(new String(new char[n]).replace("\0", " ") + line + "\n");
        }
        return sb.substring(0, sb.length() - 1);
    }

    private void write(PrintStream out, String decoration, Object... args) {
        StringBuilder sb = new StringBuilder();
        sb.append(decoration);

        for (int i = 0; i < args.length; i++) {
            if (i > 0) {
                sb.append(" ");
            }

            if (args[i] == null) {
                sb.append("null");
            } else {
                sb.append(args[i].toString());
            }
        }

        if (this.indentLevel != 0) {
            out.print(this.indentObject(sb, this.indentLevel * this.indentSize));
        } else {
            out.print(sb.toString());
        }
    }

    private void writeLn(PrintStream out, String decoration, Object... args) {
        this.write(out, decoration, args);
        out.println();
    }

    private void writeStyled(PrintStream out, String decoration, Chalk style, Object... args) {
        StringBuilder sb = new StringBuilder();
        sb.append(decoration);

        for (int i = 0; i < args.length; i++) {
            if (i > 0) {
                sb.append(" ");
            }

            if (args[i] == null) {
                sb.append(style.apply("null"));
            } else {
                sb.append(style.apply(args[i]));
            }
        }

        if (this.indentLevel != 0) {
            out.print(this.indentObject(sb, this.indentLevel * this.indentSize));
        } else {
            out.print(sb.toString());
        }
    }

    private void writeStyledLn(PrintStream out, String decoration, Chalk style, Object... args) {
        this.writeStyled(out, decoration, style, args);
        out.println();
    }

    public void _log(Object... args) {
        this.writeLn(this.stdout, "", args);
    }

    public void _info(Object... args) {
        String decoration = chalk.bgBlue().black().bold().apply(" ℹ ") + " ";
        this.writeStyledLn(this.stdout, decoration, chalk.blue(), args);
    }

    public void _warn(Object... args) {
        String decoration = chalk.bgYellow().black().bold().apply(" WARN ") + " ";
        this.writeStyledLn(this.stdout, decoration, chalk.yellow(), args);
    }

    public void _error(Object... args) {
        String decoration = chalk.bgRed().black().bold().apply(" ✗ ") + " ";
        this.writeStyledLn(this.stderr, decoration, chalk.red(), args);
    }

    public void _success(Object... args) {
        String decoration = chalk.bgGreen().black().bold().apply(" ✓ ") + " ";
        this.writeStyledLn(this.stdout, decoration, chalk.green(), args);
    }

    public void _debug(Object... args) {
        if (debugMode) {
            String decoration = chalk.bgYellow().black().bold().apply(" DEBUG ") + " ";
            this.writeLn(this.stdout, decoration, args);
        }
    }

    public void _setStdout(PrintStream stdout) {
        this.stdout = stdout;
    }

    public void _setStderr(PrintStream stderr) {
        this.stderr = stderr;
    }

    public void _setDebugMode(boolean flag) {
        this.debugMode = flag;
    }

    public void _setIndentLevel(int amount) {
        this.indentLevel = Math.max(0, amount);
    }

    public void _modIndentLevel(int amount) {
        this.indentLevel = Math.max(0, this.indentLevel + amount);
    }

    public void _setIndentSize(int size) {
        this.indentSize = Math.max(0, size);
    }

    public void _modIndentSize(int amount) {
        this.indentSize = Math.max(0, this.indentSize + amount);
    }

    public void _indent() {
        this._modIndentLevel(1);
    }

    public void _dedent() {
        this._modIndentLevel(-1);
    }

    public static void log(Object... args) {
        logger._log(args);
    }

    public static void info(Object... args) {
        logger._info(args);
    }

    public static void warn(Object... args) {
        logger._warn(args);
    }

    public static void error(Object... args) {
        logger._error(args);
    }

    public static void success(Object... args) {
        logger._success(args);
    }

    public static void debug(Object... args) {
        logger._debug(args);
    }

    public static void setStdout(PrintStream stdout) {
        logger._setStdout(stdout);
    }

    public static void setStderr(PrintStream stderr) {
        logger._setStderr(stderr);
    }

    public static void setDebugMode(boolean flag) {
        logger._setDebugMode(flag);
    }

    public static void setIndentLevel(int amount) {
        logger._setIndentLevel(amount);
    }

    public static void modIndentLevel(int amount) {
        logger._modIndentLevel(amount);
    }

    public static void setIndentSize(int size) {
        logger.indentSize = Math.max(0, size);
    }

    public static void modIndentSize(int amount) {
        logger.indentSize = Math.max(0, logger.indentSize + amount);
    }

    public static void indent() {
        logger._modIndentLevel(1);
    }

    public static void dedent() {
        logger._modIndentLevel(-1);
    }
}
