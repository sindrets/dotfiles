package io.github.sindrets.__name__;

import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.github.sindrets.jchalk.Chalk;

public class Logger {
    private static final LoggerInstance logger = new LoggerInstance();

    static {
        final String envDebug = System.getenv("DEBUG");
        setDebugMode(envDebug != null && envDebug.equals("1"));
    }

    /**
     * Create a new {@link LoggerInstance} backed by a {@link ByteArrayOutputStream}.
     * @return The new logger instance.
     */
    public static LoggerInstance createBaosLogger() {
        ByteArrayOutputStream outOS = new ByteArrayOutputStream();
        ByteArrayOutputStream errOS = new ByteArrayOutputStream();
        return new LoggerInstance(outOS, errOS);
    }

    public static LoggerInstance createLogger(OutputStream outOS, OutputStream errOS) {
        return new LoggerInstance(outOS, errOS);
    }

    public static LoggerInstance createLogger(PrintStream out, PrintStream err) {
        return new LoggerInstance(out, err);
    }

    public static LoggerInstance createLogger() {
        return new LoggerInstance();
    }

    public static String getStackTrace() {
        StringWriter sw = new StringWriter();
        new Throwable().printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    public static String getStackTrace(Throwable e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    public static void log(Object... args) {
        logger.log(args);
    }

    public static void info(Object... args) {
        logger.info(args);
    }

    public static void warn(Object... args) {
        logger.warn(args);
    }

    public static void error(Object... args) {
        logger.error(args);
    }

    public static void success(Object... args) {
        logger.success(args);
    }

    public static void debug(Object... args) {
        logger.debug(args);
    }

    public static void stackTrace(Throwable e) {
        logger.stackTrace(e);
    }

    public static void stackTrace() {
        logger.stackTrace();
    }

    public static void writeOutToFile(String path) throws IOException {
        logger.writeOutToFile(path);
    }

    public static void writeErrToFile(String path) throws IOException {
        logger.writeErrToFile(path);
    }

    public static void setOut(PrintStream out) {
        logger.setOut(out);
    }

    public static void setErr(PrintStream err) {
        logger.setErr(err);
    }

    public static void setEnabled(boolean flag) {
        logger.setEnabled(flag);
    }

    public static void setDebugMode(boolean flag) {
        logger.setDebugMode(flag);
    }

    public static void setIndentLevel(int amount) {
        logger.setIndentLevel(amount);
    }

    public static void modIndentLevel(int amount) {
        logger.modIndentLevel(amount);
    }

    public static void setIndentSize(int size) {
        logger.indentSize = Math.max(0, size);
    }

    public static void modIndentSize(int amount) {
        logger.indentSize = Math.max(0, logger.indentSize + amount);
    }

    public static void setTextWidth(int width) {
        logger.setTextWidth(width);
    }

    public static void modTextWidth(int width) {
        logger.modTextWidth(width);
    }

    public static void indent() {
        logger.modIndentLevel(1);
    }

    public static void dedent() {
        logger.modIndentLevel(-1);
    }

    public static PrintStream getOut() {
        return logger.out;
    }

    public static PrintStream getErr() {
        return logger.err;
    }

    public static boolean isEnabled() {
        return logger.enabled;
    }

    public static boolean isDebugMode() {
        return logger.debugMode;
    }

    public static int getIndentLevel() {
        return logger.indentLevel;
    }

    public static int getIndentSize() {
        return logger.indentSize;
    }

    public static OutputStream getOutOS() {
        return logger.outOS;
    }

    public static OutputStream getErrOS() {
        return logger.errOS;
    }

    public static class LoggerInstance {
        private static final Pattern wordWrapBoundsRegex = Pattern
                .compile("([\\-,.:!\\]\\})>]+)(\\s*)|(\\s+)");
        private static final Chalk chalk = new Chalk();
        private OutputStream outOS;
        private OutputStream errOS;
        private PrintStream out;
        private PrintStream err;
        private boolean enabled = true;
        private boolean debugMode = false;
        private int indentLevel = 0;
        private int indentSize = 4;
        private int textWidth = 0;

        public LoggerInstance(OutputStream outOS, OutputStream errOS) {
            this.outOS = outOS;
            this.errOS = errOS;
            this.out = new PrintStream(outOS);
            this.err = new PrintStream(errOS);
        }

        public LoggerInstance(PrintStream out, PrintStream err) {
            this.out = out;
            this.err = err;
        }

        public LoggerInstance() {
            this.out = System.out;
            this.err = System.err;
        }

        private String indentObject(Object o, int n) {
            String[] lines = o.toString().split("\\n|\\r|(\\r\\n)", -1);
            StringBuilder sb = new StringBuilder();
            String indentString = new String(new char[n]).replace("\0", " ");
            for (String line : lines) {
                sb.append(indentString + line + "\n");
            }
            return sb.substring(0, sb.length() - 1);
        }

        private String wrapObject(Object o, int width) {
            String[] lines = o.toString().split("\\n|\\r|(\\r\\n)", -1);
            StringBuilder sb = new StringBuilder();
            int indentWidth = this.indentSize * this.indentLevel;
            int freeWidth = width - indentWidth;
            String indentString = new String(new char[indentWidth]).replace("\0", " ");
            Matcher m;

            for (String line : lines) {
                StringBuilder cur = new StringBuilder();

                if (line.length() > freeWidth) {
                    m = LoggerInstance.wordWrapBoundsRegex.matcher(line);
                    MatchResult last = null;
                    int lastOffset = 0;

                    while (m.find()) {
                        if (m.end() - lastOffset > freeWidth && last != null) {
                            if (last.group(1) != null) {
                                cur.append(indentString);
                                cur.append(line.substring(lastOffset, last.end(1)) + "\n");
                                lastOffset = last.end(2);
                            } else if (last.group(3) != null) {
                                cur.append(indentString);
                                cur.append(line.substring(lastOffset, last.start(3)) + "\n");
                                lastOffset = last.end(3);
                            }
                        }

                        last = m.toMatchResult();
                    }

                    cur.append(indentString + line.substring(lastOffset) + "\n");
                } else {
                    cur.append(indentString + line + "\n");
                }

                sb.append(cur);
            }

            return sb.substring(0, sb.length() - 1);
        }

        private void write(PrintStream out, String decoration, Object... args) {
            if (!this.enabled) {
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.append(decoration);

            for (int i = 0; i < args.length; i++) {
                if (i > 0) {
                    sb.append(" ");
                }

                if (args[i] == null) {
                    sb.append("null");
                } else if (args[i].getClass().isArray()) {
                    sb.append(Arrays.toString((Object[]) args[i]));
                } else {
                    sb.append(args[i].toString());
                }
            }

            if (this.textWidth > 0) {
                out.print(this.wrapObject(sb, this.textWidth));
            } else if (this.indentLevel != 0) {
                out.print(this.indentObject(sb, this.indentLevel * this.indentSize));
            } else {
                out.print(sb.toString());
            }
        }

        private void writeLn(PrintStream out, String decoration, Object... args) {
            if (!this.enabled) {
                return;
            }

            this.write(out, decoration, args);
            out.println();
        }

        private void writeStyled(PrintStream out, String decoration, Chalk style, Object... args) {
            if (!this.enabled) {
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.append(decoration);

            for (int i = 0; i < args.length; i++) {
                if (i > 0) {
                    sb.append(" ");
                }

                if (args[i] == null) {
                    sb.append(style.apply("null"));
                } else if (args[i].getClass().isArray()) {
                    sb.append(style.apply(Arrays.toString((Object[]) args[i])));
                } else {
                    sb.append(style.apply(args[i]));
                }
            }

            if (this.textWidth > 0) {
                out.print(this.wrapObject(sb, this.textWidth));
            } else if (this.indentLevel != 0) {
                out.print(this.indentObject(sb, this.indentLevel * this.indentSize));
            } else {
                out.print(sb.toString());
            }
        }

        private void writeStyledLn(PrintStream out, String decoration, Chalk style,
                Object... args) {

            if (!this.enabled) {
                return;
            }

            this.writeStyled(out, decoration, style, args);
            out.println();
        }

        public void log(Object... args) {
            this.writeLn(this.out, "", args);
        }

        public void info(Object... args) {
            String decoration = chalk.bgBlue().black().bold().apply(" ℹ ") + " ";
            this.writeStyledLn(this.out, decoration, chalk.blue(), args);
        }

        public void warn(Object... args) {
            String decoration = chalk.bgYellow().black().bold().apply(" WARN ") + " ";
            this.writeStyledLn(this.out, decoration, chalk.yellow(), args);
        }

        public void error(Object... args) {
            String decoration = chalk.bgRed().black().bold().apply(" ✗ ") + " ";
            this.writeStyledLn(this.err, decoration, chalk.red(), args);
        }

        public void success(Object... args) {
            String decoration = chalk.bgGreen().black().bold().apply(" ✓ ") + " ";
            this.writeStyledLn(this.out, decoration, chalk.green(), args);
        }

        public void debug(Object... args) {
            if (debugMode) {
                boolean wasEnabled = this.enabled;
                this.setEnabled(true);
                String decoration = chalk.bgYellow().black().bold().apply(" DEBUG ") + " ";
                this.writeLn(this.out, decoration, args);
                this.setEnabled(wasEnabled);
            }
        }

        public void stackTrace(Throwable e) {
            this.indent();
            this.log(chalk.blackBright().apply(Logger.getStackTrace(e)));
            this.dedent();
        }

        public void stackTrace() {
            this.indent();
            this.log(chalk.blackBright().apply(Logger.getStackTrace()));
            this.dedent();
        }

        public void writeOutToFile(String path) throws IOException {
            FileWriter file = new FileWriter(path);
            file.write(this.outOS.toString());
            file.close();
        }

        public void writeErrToFile(String path) throws IOException {
            FileWriter file = new FileWriter(path);
            file.write(this.errOS.toString());
            file.close();
        }

        public void setOut(PrintStream out) {
            this.out = out;
        }

        public void setErr(PrintStream err) {
            this.err = err;
        }

        public void setEnabled(boolean flag) {
            this.enabled = flag;
        }

        public void setDebugMode(boolean flag) {
            this.debugMode = flag;
        }

        public void setIndentLevel(int amount) {
            this.indentLevel = Math.max(0, amount);
        }

        public void modIndentLevel(int amount) {
            this.indentLevel = Math.max(0, this.indentLevel + amount);
        }

        public void setIndentSize(int size) {
            this.indentSize = Math.max(0, size);
        }

        public void modIndentSize(int amount) {
            this.indentSize = Math.max(0, this.indentSize + amount);
        }

        public void setTextWidth(int width) {
            this.textWidth = Math.max(0, width);
        }

        public void modTextWidth(int width) {
            this.textWidth = Math.max(0, this.textWidth + width);
        }

        public void indent() {
            this.modIndentLevel(1);
        }

        public void dedent() {
            this.modIndentLevel(-1);
        }

        public PrintStream getOut() {
            return out;
        }

        public PrintStream getErr() {
            return err;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public boolean isDebugMode() {
            return debugMode;
        }

        public int getIndentLevel() {
            return indentLevel;
        }

        public int getIndentSize() {
            return indentSize;
        }

        public OutputStream getOutOS() {
            return outOS;
        }

        public OutputStream getErrOS() {
            return errOS;
        }
    }
}
