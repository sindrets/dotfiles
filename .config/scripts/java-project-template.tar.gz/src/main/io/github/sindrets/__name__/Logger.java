package io.github.sindrets.__name__;

import no.stide.jchalk.Chalk;

public class Logger {

    private static final Chalk chalk = new Chalk();
    private static boolean debugMode = false;

    public static void log(Object... args) {
        for (int i = 0; i < args.length; i++) {
            if (i > 0)
                System.out.print(" ");
            System.out.print(args[i].toString());
        }
        System.out.println();
    }

    public static void info(Object... args) {
        System.out.print(chalk.bgBlue().black().bold().apply(" ℹ ") + " ");
        for (int i = 0; i < args.length; i++) {
            if (i > 0)
                System.out.print(" ");
            System.out.print(chalk.blue().apply(args[i]));
        }
        System.out.println();
    }

    public static void warn(Object... args) {
        System.out.print(chalk.bgYellow().black().bold().apply(" WARN ") + " ");
        for (int i = 0; i < args.length; i++) {
            if (i > 0)
                System.out.print(" ");
            System.out.print(chalk.yellow().apply(args[i]));
        }
        System.out.println();
    }

    public static void error(Object... args) {
        System.out.print(chalk.bgRed().black().bold().apply(" ✗ ") + " ");
        for (int i = 0; i < args.length; i++) {
            if (i > 0)
                System.out.print(" ");
            System.out.print(chalk.red().apply(args[i]));
        }
        System.out.println();
    }

    public static void success(Object... args) {
        System.out.print(chalk.bgGreen().black().bold().apply(" ✓ ") + " ");
        for (int i = 0; i < args.length; i++) {
            if (i > 0)
                System.out.print(" ");
            System.out.print(chalk.green().apply(args[i]));
        }
        System.out.println();
    }

    public static void debug(Object... args) {
        if (debugMode) {
            System.out.print(chalk.bgYellow().black().bold().apply(" DEBUG ") + " ");
            for (int i = 0; i < args.length; i++) {
                if (i > 0)
                    System.out.print(" ");
                System.out.print(args[i].toString());
            }
            System.out.println();
        }
    }

    public static void setDebugMode(boolean flag) {
        debugMode = flag;
    }
}
