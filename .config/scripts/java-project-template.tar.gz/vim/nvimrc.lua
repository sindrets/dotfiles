local M = {}

vim.cmd([[
augroup project_init
  au!
  au FileType java setlocal et cc=100 tw=100 spell
  au FileType markdown setlocal et cc=80 tw=80
augroup END
]])

M.lsp_config = {
  ["java.project.referencedLibraries"] = {
    "lib/**/*.jar",
    "lib/*.jar"
  },
  ["java.format.settings.url"] = "eclipse-formatter.xml",
}

return M
